//
//  main.m
//  AppointmentList
//
//  Created by Ole Begemann on 01.12.11.
//  Copyright (c) 2011 Ole Begemann. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
