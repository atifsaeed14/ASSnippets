//
//  GAIManager.h
//  GoogleAnalyticsSample
//

#import <Foundation/Foundation.h>

#import "GAI.h"
#import "GAIDictionaryBuilder.h"
#import "GAIFields.h"

typedef enum{
    
    GAILogCategoryGeneral = 0,
    GAILogCategoryError,
    
    
}GAILogCategory;



@interface GAIManager : NSObject
{
    
}


+(void)startWithTrackingID:(NSString *)trackingID;

// logsTitle is used to describe the "value".
// e.g logs = "Products could not be downloaded" for logsTitle = "GetProductData" category "GAILogCategoryError"

// Limit for logs and logsTitle is 500 Bytes.
+(void)sendLogs:(NSString *)logs withLogsTitle:(NSString *)logsTitle forCategory:(GAILogCategory)category;

@end
