//
//  GAIManager.m
//  GoogleAnalyticsSample
//



#import "GAIManager.h"

static BOOL trackingAllowed = YES;
static NSString *kGAIAllowTracking = @"Tracking_Allowed";
static NSArray *categories;

@interface GAIManager ()
{
    
}
@end


@implementation GAIManager

+(void)startWithTrackingID:(NSString *)trackingID{
    
    NSDictionary *appDefaults = @{kGAIAllowTracking: @(trackingAllowed)};
    [[NSUserDefaults standardUserDefaults] registerDefaults:appDefaults];
    [GAI sharedInstance].optOut =
    ![[NSUserDefaults standardUserDefaults] boolForKey:kGAIAllowTracking];
    [[GAI sharedInstance] setTrackUncaughtExceptions:YES];
    [GAI sharedInstance].dispatchInterval = 120;
    [[[GAI sharedInstance] logger] setLogLevel:kGAILogLevelInfo];
    
    NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
    
    NSString *trackerName = [NSString stringWithFormat:@"%@ (%@)",[infoDictionary objectForKey:@"CFBundleDisplayName"],[infoDictionary objectForKey:@"CFBundleVersion"]];
    
    [[GAI sharedInstance] trackerWithName:trackerName
                               trackingId:trackingID];
    
    
    NSSetUncaughtExceptionHandler(&uncaughtExceptionHandler);
    
    if(categories == nil){
        categories = @[@"General",
                       @"Error"];
    }
    
}

+(void)sendLogs:(NSString *)logs withLogsTitle:(NSString *)logsTitle forCategory:(GAILogCategory)category{
    
    if(trackingAllowed == NO){
        return;
    }
    
    id<GAITracker>tracker = [[GAI sharedInstance] defaultTracker];
    [tracker send:[[GAIDictionaryBuilder createEventWithCategory:categories[category] action:logsTitle label:logs value:@1] build]];
    [[GAI sharedInstance] dispatch];
}

void uncaughtExceptionHandler(NSException *exception) {
    
    if(trackingAllowed == NO){
        return;
    }
    
    
    NSString *crashString = nil;
    
           crashString = [NSString stringWithFormat:@"[%@] %@",[exception callStackSymbols]];
    
    id<GAITracker>tracker = [GAI sharedInstance].defaultTracker;
    [tracker send:[[GAIDictionaryBuilder createExceptionWithDescription:crashString withFatal:@YES] build]];
    
    [[GAI sharedInstance] dispatch];
}

@end
