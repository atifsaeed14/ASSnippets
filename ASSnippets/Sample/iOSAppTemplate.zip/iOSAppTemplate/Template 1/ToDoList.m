//
//  ToDoList.m
//  iOSAppTemplate
//
//  Created by Rafael on 18/01/14.
//  Copyright (c) 2014 Rafael Colatusso. All rights reserved.
//

#import "ToDoList.h"


@implementation ToDoList

@dynamic text;
@dynamic objectId;

@end
