//
//  VC2.h
//  ASNavMenu
//
//  Created by Atif Saeed on 6/3/15.
//  Copyright (c) 2015 atti14. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface VC2 : UIViewController

@end
