//
//  VC1.m
//  ASNavMenu
//
//  Created by Atif Saeed on 6/3/15.
//  Copyright (c) 2015 atti14. All rights reserved.
//

#import "VC1.h"
#import "VC2.h"
#import "CCKFNavDrawer.h"

@interface VC1 ()

@property (strong, nonatomic) CCKFNavDrawer *rootNav;

@end

@implementation VC1

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.title = @"1";
    
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.rootNav = (CCKFNavDrawer *)self.navigationController;

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    
}

- (IBAction)pushViewController:(id)sender {
    
    VC2 *cv = [VC2 new];
//    [self.rootNav pushViewController:cv animated:YES];
    [self.navigationController pushViewController:cv animated:YES];
//    VC1 *cv = [VC1 new];
//    [self.rootNav pushViewController:cv animated:YES];


//    [self.navigationController pushViewController:cv animated:YES];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
