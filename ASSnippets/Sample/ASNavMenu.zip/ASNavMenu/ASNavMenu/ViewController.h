//
//  ViewController.h
//  ASNavMenu
//
//  Created by Atif Saeed on 6/3/15.
//  Copyright (c) 2015 atti14. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CCKFNavDrawer.h"

@interface ViewController : UIViewController <CCKFNavDrawerDelegate>


- (IBAction)pushViewController:(id)sender;

@end
