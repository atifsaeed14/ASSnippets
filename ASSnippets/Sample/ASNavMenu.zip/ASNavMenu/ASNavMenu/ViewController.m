//
//  ViewController.m
//  ASNavMenu
//
//  Created by Atif Saeed on 6/3/15.
//  Copyright (c) 2015 atti14. All rights reserved.
//

#import "ViewController.h"
#import "VC1.h"
#import "VC2.h"

@interface ViewController () 

@property (strong, nonatomic) CCKFNavDrawer *rootNav;

@property (strong, nonatomic) VC1 *vc1;
@property (strong, nonatomic) VC2 *vc2;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.title = @"VC";
    
    self.rootNav = (CCKFNavDrawer *)self.navigationController;
    [self.rootNav setCCKFNavDrawerDelegate:self];
    
    _vc1 = [VC1 new];
    self.vc1.view.tag = 999;

    _vc2 = [VC2 new];
    self.vc2.view.tag = 999;

    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)drawerToggle:(id)sender {
    [self.rootNav drawerToggle];
}

#pragma mark - photoShotSavedDelegate

-(void)CCKFNavDrawerSelection:(NSInteger)selectionIndex
{
    NSLog(@"CCKFNavDrawerSelection =");
    
    [self removeSubviews];

    
    if (selectionIndex == 0) {
        //[self.view removeFromSuperview];
        //[self.view addSubview:self.vc1.view];
    }
    
    if (selectionIndex == 1) {
        //[self.view  removeFromSuperview];
        [self.view addSubview:self.vc1.view];
    }
    if (selectionIndex == 2) {
        //[self.view removeFromSuperview];
        [self.view addSubview:self.vc2.view];
    }

//    NSLog(@"CCKFNavDrawerSelection = %i", selectionIndex);
//    self.selectionIdx.text = [NSString stringWithFormat:@"%i",selectionIndex];
}

- (void)removeSubviews {
    // remove the current subview loaded
    for (UIView *view in [self.view subviews]) {
        if (view.tag == 999) {
            [view removeFromSuperview];
        }
    }
}

- (IBAction)pushViewController:(id)sender {
    VC1 *cv = [VC1 new];
    [self.rootNav pushViewController:cv animated:YES];
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
