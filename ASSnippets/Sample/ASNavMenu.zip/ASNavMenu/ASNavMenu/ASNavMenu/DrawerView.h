//
//  Drawer.h
//  CCKFNavDrawer
//
//  Created by calvin on 2/2/14.
//  Copyright (c) 2014年 com.calvin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DrawerView : UIView

@property (weak, nonatomic) IBOutlet UITableView *drawerTableView;

@end
