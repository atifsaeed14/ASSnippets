//
//  ImageManager.m
//  Gallery
//
//  Created by Atif Saeed on 21/01/2014.
//  Copyright (c) 2014 Atif Saeed. All rights reserved.
//

#import "ImageManager.h"

static ImageManager *shareManager = nil;

@implementation ImageManager

+ (ImageManager *)sharedManager {
    if(shareManager==nil)
        shareManager = [[self alloc] init];
    return shareManager;
}

- (id)init {
    self = [super init];
    if(self) {
        self.imageList = [[NSArray alloc] init];
    }
    return self;
}

#pragma mark - Gallery Image List
- (NSArray *)fetchingImages {
    self.imageList = @[@"photo1.png",@"photo2.png",@"photo3.png"];
    return self.imageList;
}

@end
