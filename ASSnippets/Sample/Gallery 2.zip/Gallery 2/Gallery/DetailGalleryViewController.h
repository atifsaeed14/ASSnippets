//
//  DetailGalleryViewController.h
//  Gallery
//
//  Created by Atif Saeed on 21/01/2014.
//  Copyright (c) 2014 Atif Saeed. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailGalleryViewController : UIViewController <UIScrollViewDelegate>

@property (strong,nonatomic) IBOutlet UIScrollView *scrollView;
@property (nonatomic, unsafe_unretained) CGFloat currentScale;


@property (assign, nonatomic) int current;
@property (strong, nonatomic) NSArray *imageList;
@property (strong, nonatomic) UIImage *image;
@property (strong, nonatomic) UIImageView *imageViewer;
@property (strong, nonatomic) UIActivityIndicatorView *spinner;

@property (nonatomic, strong) UISwipeGestureRecognizer *swipeGestureRecognizerLeft;
@property (nonatomic, strong) UISwipeGestureRecognizer *swipeGestureRecognizerRight;
//@property (nonatomic, strong) UIPinchGestureRecognizer *pinchGestureRecognizer;

@end
