//
//  AppDelegate.h
//  Gallery
//
//  Created by Atif Saeed on 21/01/2014.
//  Copyright (c) 2014 Atif Saeed. All rights reserved.
//

#import <UIKit/UIKit.h>

@class GalleryViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) GalleryViewController *galleryVC;
@end
