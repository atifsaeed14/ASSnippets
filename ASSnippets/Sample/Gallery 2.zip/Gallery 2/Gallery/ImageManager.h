//
//  ImageManager.h
//  Gallery
//
//  Created by Atif Saeed on 21/01/2014.
//  Copyright (c) 2014 Atif Saeed. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ImageManager : NSObject{
}

+ (ImageManager *)sharedManager;
@property (strong, nonatomic) NSArray *imageList;
- (NSArray *)fetchingImages;;

@end
