//
//  DetailGalleryViewController.m
//  Gallery
//
//  Created by Atif Saeed on 21/01/2014.
//  Copyright (c) 2014 Atif Saeed. All rights reserved.
//

#import "DetailGalleryViewController.h"
#import "ImageManager.h"

@interface DetailGalleryViewController () {
    NSString *imageName;
    NSArray *imageNameArray;
    CGRect imageViewRect;
    CATransition *transition;
}
@end

@implementation DetailGalleryViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}


- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
//    // Set up the minimum & maximum zoom scales
    //CGRect scrollViewFrame = self.scrollView.frame;
//    CGFloat scaleWidth = scrollViewFrame.size.width / self.scrollView.contentSize.width;
//    CGFloat scaleHeight = scrollViewFrame.size.height / self.scrollView.contentSize.height;
//    //CGFloat minScale = MIN(scaleWidth, scaleHeight);
//    
//    CGFloat minScale = MIN(320, 410);
//    
//    self.scrollView.minimumZoomScale = minScale;
//    //self.scrollView.minimumZoomScale = CGRectMake(0, 70, 320, 410);
//    self.scrollView.maximumZoomScale = 1.0f;
//    self.scrollView.zoomScale = minScale;
    
    //[self centerScrollViewContents];
}

//- (void)centerScrollViewContents {
//    CGSize boundsSize = self.scrollView.bounds.size;
//    CGRect contentsFrame = self.imageViewer.frame;
//    
//    if (contentsFrame.size.width < boundsSize.width) {
//        contentsFrame.origin.x = (boundsSize.width - contentsFrame.size.width) / 2.0f;
//    } else {
//        contentsFrame.origin.x = 0.0f;
//    }
//    
//    if (contentsFrame.size.height < boundsSize.height) {
//        contentsFrame.origin.y = (boundsSize.height - contentsFrame.size.height) / 2.0f;
//    } else {
//        contentsFrame.origin.y = 0.0f;
//    }
//    
//    self.imageViewer.frame = contentsFrame;
//}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    //self.scrollView.delegate = self;
    
    /* UIActivity Indicator */
//    self.spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
//    self.spinner.color = [UIColor redColor];
//    [self.spinner setCenter:CGPointMake(160, 250)];
//    [self.spinner startAnimating];
//    [self.view addSubview:self.spinner];
    
    /* Image List */
    self.imageList = [[ImageManager sharedManager] fetchingImages];
    
    /* Title */
    imageName = [self.imageList objectAtIndex:self.current];
    imageNameArray = [imageName componentsSeparatedByString:@"."];
    self.title = [imageNameArray objectAtIndex:0];
    
    /* Invoking backgrounds methods, easy way to creaet threads without having to deal with threadas directly */
    //[self performSelectorInBackground:@selector(loadImage) withObject:nil];
    
    
//    if ([UIScreen mainScreen].bounds.size.height==480){
//        imageViewRect = CGRectMake(0, 0, 320, 480);
//    } else if ([UIScreen mainScreen].bounds.size.height==568) {
//        imageViewRect = CGRectMake(0, 0, 320, 568);
//    }
    
    NSLog(@"height: %f",self.view.bounds.size.height);

    
    //imageViewRect = self.view.bounds;
    imageViewRect = CGRectMake(self.scrollView.bounds.origin.x, self.scrollView.bounds.origin.y-60, self.scrollView.bounds.size.width, self.scrollView.bounds.size.height-0);
    //_scrollView = CGRectMake(0, 0, 100, 200);
    
    /* Instantiate object */
    self.swipeGestureRecognizerLeft = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(handleSwipes:)];
    self.swipeGestureRecognizerRight = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(handleSwipes:)];
    //self.pinchGestureRecognizer =  [[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(handlePinches:)];
    
    /* Swipes that are performed from right to left are to be detected */
    self.swipeGestureRecognizerRight.direction = UISwipeGestureRecognizerDirectionLeft;
    /* Swipes that are performed from left to right are to be detected */
    self.swipeGestureRecognizerLeft.direction = UISwipeGestureRecognizerDirectionRight;
    /* Add this gesture recognizer to scrollview */
    //[self.scrollView addGestureRecognizer:self.pinchGestureRecognizer];
    
    /* Just one finger needed */
    self.swipeGestureRecognizerLeft.numberOfTouchesRequired = 1;
    self.swipeGestureRecognizerRight.numberOfTouchesRequired = 1;
    
    /* Add it to the view */
    [self.view addGestureRecognizer:self.swipeGestureRecognizerLeft];
    [self.view addGestureRecognizer:self.swipeGestureRecognizerRight];
    
    self.image = [UIImage imageNamed:[self.imageList objectAtIndex:self.current]];
    self.imageViewer = [[UIImageView alloc] initWithFrame:imageViewRect];
    self.imageViewer.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.imageViewer.contentMode = UIViewContentModeScaleToFill;
    self.imageViewer.image = self.image;
    
    [_scrollView addSubview:self.imageViewer];

    
    self.scrollView.minimumZoomScale=1;
    self.scrollView.maximumZoomScale = 5.0;
    //self.scrollView.contentSize=CGSizeMake(1280, 960);
    //self.scrollView.contentSize = self.image.size;
    self.scrollView.delegate=self;
    
//    NSLog(@"Image Size: %@",NSStringFromCGSize(_imageViewer.frame.origin.y));
//
//NSLog(@"Scroll View: %@",NSStringFromCGSize(_scrollView.frame.origin));
//    
    // Tell the scroll view the size of the contents
   
//    NSLog(@"height: %f",self.scrollView.contentSize.height);
//    NSLog(@"weiht: %f",self.scrollView.contentSize.width);
    
}

- (void) handleSwipes:(UISwipeGestureRecognizer *)paramSender{
    
    if (paramSender.direction & UISwipeGestureRecognizerDirectionDown){
        NSLog(@"Swiped Down.");
    }
    if (paramSender.direction & UISwipeGestureRecognizerDirectionLeft){
        NSLog(@"Swiped Left.");
        if([self.imageList objectAtIndex:self.current]==[self.imageList lastObject])
            return;
        self.current++;
        
        
//        CATransition *transition = [CATransition animation];
//        transition.duration = 0.5;
//        transition.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionDefault];
//        transition.type = kCATransitionPush;
//        transition.subtype = kCATransitionFromRight;
//        transition.delegate = self;
//        [[self.imageViewer layer] addAnimation:transition forKey:nil];
        
        //http://stackoverflow.com/questions/630265/iphone-uiview-animation-best-practice?rq=1
        
        /* transition */
        transition = [CATransition animation];
        [transition setDuration:1];
        [transition setType:kCATransitionReveal];
        transition.subtype = kCATransitionFromRight;
        [transition setTimingFunction:[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseIn]];
        [[self.imageViewer layer] addAnimation:transition forKey:nil];
        
        
        [self loadImage];
        //[self performSelector:@selector(loadImage) withObject:nil afterDelay:0.1];
    }
    if (paramSender.direction & UISwipeGestureRecognizerDirectionRight){
        NSLog(@"Swiped Right.");
        if([self.imageList objectAtIndex:self.current]==[self.imageList objectAtIndex:0])
            return;
        self.current--;
        
        /* transition */
        transition = [CATransition animation];
        [transition setDuration:1];
        [transition setType:kCATransitionReveal];
        transition.subtype = kCATransitionFromLeft;
        [transition setTimingFunction:[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseIn]];
        [[self.imageViewer layer] addAnimation:transition forKey:nil];
        
        [self loadImage];
        
        
        
        //[self performSelector:@selector(loadImage) withObject:nil afterDelay:1];
        
    }
    if (paramSender.direction & UISwipeGestureRecognizerDirectionUp){
        NSLog(@"Swiped Up.");
    }
    
}

//- (void) handlePinches:(UIPinchGestureRecognizer*)paramSender{
//    
//    
//    CGFloat newZoomScale = self.scrollView.zoomScale / 1.5f;
//    newZoomScale = MAX(newZoomScale, self.scrollView.minimumZoomScale);
//    [self.scrollView setZoomScale:newZoomScale animated:YES];
//    
//    
////    if (paramSender.state == UIGestureRecognizerStateEnded){
////        self.currentScale = paramSender.scale;
////    } else if (paramSender.state == UIGestureRecognizerStateBegan &&
////               self.currentScale != 0.0f){
////        paramSender.scale = self.currentScale;
////    }
////    
////    if (paramSender.scale != NAN &&
////        paramSender.scale != 0.0){
////        paramSender.view.transform =
////        CGAffineTransformMakeScale(paramSender.scale,
////                                   paramSender.scale);
////    }
//    
//}

//- (void)scrollViewTwoFingerTapped:(UITapGestureRecognizer*)recognizer {
//    // Zoom out slightly, capping at the minimum zoom scale specified by the scroll view
//    CGFloat newZoomScale = self.scrollView.zoomScale / 1.5f;
//    newZoomScale = MAX(newZoomScale, self.scrollView.minimumZoomScale);
//    [self.scrollView setZoomScale:newZoomScale animated:YES];
//}

-(void)loadImage {
    
    
    imageName = [self.imageList objectAtIndex:self.current];
    imageNameArray = [imageName componentsSeparatedByString:@"."];
    self.title = [imageNameArray objectAtIndex:0];
    
    
//    NSString *str = @"Hi,Hello,Bye";
//    NSArray *arr = [str componentSeparatedBy:@","];
//    NSString *strHi = [arr objectAtIndex:0];
    
    [self showActivityIndicator];
    self.image = [UIImage imageNamed:[self.imageList objectAtIndex:self.current]];
    self.imageViewer.image = self.image;
    [self hideActivityIndicator];
    //self.scrollView.contentSize = self.imageViewer.frame.size;//self.image.size;
    //self.scrollView.clipsToBounds = YES;
}

- (UIView*)viewForZoomingInScrollView:(UIScrollView *)scrollView {
    // Return the view that we want to zoom
    return self.imageViewer;
}


- (void)scrollViewDidZoom:(UIScrollView *)scrl {
    NSLog(@"Image Size: %@",NSStringFromCGSize(_imageViewer.frame.size));
    self.scrollView.contentSize = self.imageViewer.frame.size;
    // The scroll view has zoomed, so we need to re-center the contents
    //[self centerScrollViewContents];
}

#pragma mark - Helper Methods

- (void)showActivityIndicator
{
    [self.spinner startAnimating];
}

-(void)hideActivityIndicator
{
    [self.spinner stopAnimating];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
