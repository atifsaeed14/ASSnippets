//
//  StoreAnnotation.m
// Doppio
//
//  Created by Christian Roman on 22/12/13.
//  Copyright (c) 2013 Christian Roman. All rights reserved.
//

#import "StoreAnnotation.h"

@implementation StoreAnnotation

@end
