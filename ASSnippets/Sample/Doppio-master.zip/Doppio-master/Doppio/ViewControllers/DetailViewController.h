//
//  DetailViewController.h
// Doppio
//
//  Created by Christian Roman on 23/12/13.
//  Copyright (c) 2013 Christian Roman. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Store;

@interface DetailViewController : UIViewController

@property (nonatomic, strong) Store *store;

@end
