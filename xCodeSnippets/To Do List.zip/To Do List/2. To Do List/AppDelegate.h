//
//  AppDelegate.h
//  2. To Do List
//
//  Created by Netsolace on 19/11/13.
//  Copyright (c) 2013 atif. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "mainViewController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) mainViewController *mainVC;
@property (strong, nonatomic) UINavigationController *mainNav;

@end
