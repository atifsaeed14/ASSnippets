//
//  addViewController.m
//  2. To Do List
//
//  Created by Netsolace on 19/11/13.
//  Copyright (c) 2013 atif. All rights reserved.
//

#import "addViewController.h"

@interface addViewController ()

@end

@implementation addViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    /* title */
    self.title = @"Add Item";
    
    self.addMessage.text = @"";
    
    /* keypad hidden */
    self.itemName.delegate = self;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(void)backPressed:(UIButton *)sender
{
    [self dismissModalViewControllerAnimated:YES];
}

-(void)addPressed:(UIButton *)sender
{
    NSString *itemName = self.itemName.text;
    if ([itemName length] == 0) {
        
        self.addMessage.text = @"Can't add because Textfield is empty...?";
        
    }else {
        
        self.itemName.text = nil;
        [self.view endEditing:YES];
        NSLog(@"itemName: %@",itemName);
        self.addMessage.text = @"Item name add successfull...!";
        
        /* dictionary object */
        NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
        [dic setObject:itemName forKey:@"title"];
        [dic setObject:@"NO" forKey:@"state"];
        
        /* add dictionary object to array */
        [self.addItem addObject:dic];
        
        /* write to plist */
        [self.addItem writeToFile:self.path atomically:YES];
    }
    
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return NO;
}

@end
