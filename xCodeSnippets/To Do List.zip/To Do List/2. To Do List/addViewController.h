//
//  addViewController.h
//  2. To Do List
//
//  Created by Netsolace on 19/11/13.
//  Copyright (c) 2013 atif. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface addViewController : UIViewController <UITextFieldDelegate>

@property (strong, nonatomic) NSMutableArray *addItem;
@property (strong, nonatomic) NSString *path;
@property (strong, nonatomic) IBOutlet UITextField *itemName;
@property (strong, nonatomic) IBOutlet UILabel *addMessage;
-(IBAction)backPressed:(UIButton *)sender;
-(IBAction)addPressed:(UIButton *)sender;

@end
