//
//  mainViewController.h
//  2. To Do List
//
//  Created by Netsolace on 19/11/13.
//  Copyright (c) 2013 atif. All rights reserved.
//

#import <UIKit/UIKit.h>

@class addViewController;

@interface mainViewController : UIViewController <UITableViewDelegate,UITableViewDataSource> {
    
    addViewController *addVC;
}


@property (strong, nonatomic) IBOutlet UITableView *listUITable;
//@property (strong, nonatomic) NSArray *item;

@property (strong, nonatomic) NSString *path;

@property (strong, nonatomic) NSMutableArray *listItem;

- (void)callAddForm;
- (void)callEditTable;
- (void)exitEditingMode;
@end
