//
//  mainViewController.m
//  2. To Do List
//
//  Created by Netsolace on 19/11/13.
//  Copyright (c) 2013 atif. All rights reserved.
//

#import "mainViewController.h"
#import "addViewController.h"

@interface mainViewController ()

@end

@implementation mainViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    /* title */
    self.title = @"To Do List";
    
    /* bar left button */
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemEdit target:self action:@selector(callEditTable)];
    
    /* bar right button */
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"Add" style:UIBarButtonItemStylePlain target:self action:@selector(callAddForm)];
    
    /* list item */
    //self.item = @[@"fruit", @"vegetable"];
    //NSLog(@"%@",self.item);
    
    /* plist */
    NSError *error;
    
    /* ceate a list path */
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    
    /* get a path to your documents directory from the list */
    NSString *documentsDirectory = [paths objectAtIndex:0];
    
    /* get ful path */
    self.path = [documentsDirectory stringByAppendingPathComponent:@"data.plist"];
    //NSLog(@"Path: %@",self.path);
    
    /* or to get path using this */
    //NSString *dataFile = [NSHomeDirectory() stringByAppendingFormat:@"/Documents/"];
    //NSLog(@"dataFile: %@",dataFile);
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    /* check if file exit */
    if(![fileManager fileExistsAtPath:self.path])
    {
        /* get a path to your plist created before in bundle directory (by Xcode) */
        NSString *resPath = [[NSBundle mainBundle] pathForResource:@"data" ofType:@"plist"];
        //NSLog(@"resPath: %@",resPath);
        
        /* copy this plist to your documents directory */
        [fileManager copyItemAtPath:resPath toPath:self.path error:&error];
    }
    
    /* copy plist item into array */
    self.listItem = [[NSMutableArray alloc]initWithContentsOfFile:self.path];
    //NSLog(@"%@",self.listItem);

    /* inital dictionarly */
//    NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
//    [dic setObject:@"d" forKey:@"title"];
//    [dic setObject:@"YES" forKey:@"state"];
//    [self.listItem addObject:dic];
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.listItem count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    
    NSDictionary *temDic = [self.listItem objectAtIndex:indexPath.row];
    //NSLog(@"l: %@",temDic);
    
    
    id title = [temDic objectForKey:@"title"];
    //NSLog(@"%@",value);
    
    //NSString *abc = [self.item objectAtIndex:indexPath.row];
    cell.textLabel.text = title;
    
    id state = [temDic objectForKey:@"state"];
    BOOL success = [state boolValue];
    //NSLog(@"%d",success);
    if (success) {
        cell.accessoryType = UITableViewCellAccessoryCheckmark;
    }     
    return cell;
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (indexPath.row < 2) {
        return UITableViewCellAccessoryNone;
    }else {
        return UITableViewCellEditingStyleDelete;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSMutableDictionary *temDic = [self.listItem objectAtIndex:indexPath.row];
    UITableViewCell *cell = [self.listUITable cellForRowAtIndexPath:indexPath];
    if (cell.accessoryType == UITableViewCellAccessoryNone) {
        [cell setAccessoryType:UITableViewCellAccessoryCheckmark];
        [temDic setObject:@"YES" forKey:@"state"];
    } else {
        [cell setAccessoryType:UITableViewCellAccessoryNone];
        [temDic setObject:@"NO" forKey:@"state"];
        
    }
    
    [self.listItem replaceObjectAtIndex:indexPath.row withObject:temDic];
    //NSLog(@"%@",temDic);
    [self.listItem writeToFile:self.path atomically:YES];
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        if (indexPath.row < [self.listItem count]) {
            /* first remove this object from the source */
            [self.listItem removeObjectAtIndex:indexPath.row];
            /* remove this from plist */
            [self.listItem writeToFile:self.path atomically:YES];
            /* then remove the associated cell from the Table View */
            [self.listUITable deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationLeft];
        }
    }
    NSLog(@"delete call");
}

- (void)callEditTable {
    self.listUITable.editing = YES;
    /* bar left button */
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(exitEditingMode)];
}

- (void)exitEditingMode {
    self.listUITable.editing=NO;
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemEdit target:self action:@selector(callEditTable)];
}

- (void)callAddForm {
    addVC = [[addViewController alloc]initWithNibName:@"addViewController" bundle:nil];
    //[self.navigationController pushViewController:addVC animated:YES];
    addVC.addItem = self.listItem;
    addVC.path = self.path;
    [self presentModalViewController:addVC animated:YES];
}


-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.listUITable reloadData];
}

@end
