//
//  GalleryViewController.m
//  Gallery
//
//  Created by Atif Saeed on 21/01/2014.
//  Copyright (c) 2014 Atif Saeed. All rights reserved.
//

#import "GalleryViewController.h"
#import "ImageManager.h"

@interface GalleryViewController ()

@end

@implementation GalleryViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.title = @"Gallery";
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    /* UIActivity Indicator */
    self.spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    self.spinner.color = [UIColor redColor];
    [self.spinner setCenter:CGPointMake(160, 250)];
    [self.spinner startAnimating];
    [self.view addSubview:self.spinner];

    /* Invoking backgrounds methods, easy way to creaet threads without having to deal with threadas directly */
    [self performSelectorInBackground:@selector(loadImages) withObject:nil];

}

- (void)loadImages
{
    
    CGRect scrollViewRect = self.view.bounds;
    //NSLog(@"x:%f, y:%f, h:%f, w:%f",scrollViewRect.origin.x,scrollViewRect.origin.y,scrollViewRect.size.height,scrollViewRect.size.width);
    
    if ([UIScreen mainScreen].bounds.size.height==480){
        self.scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 70, 320, 410)];
        //NSLog(@"3.5 inch screen");
    } else if ([UIScreen mainScreen].bounds.size.height==568) {
        self.scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 70, 320, 498)];
        //NSLog(@"4.0 inch screen");
    }
    
    self.imageList = [[ImageManager sharedManager] fetchingImages];
    
    int noOfButton = (int)[self.imageList count];
    
    float a = noOfButton / 3;
    //NSLog(@"%f",a);
    
    int b = noOfButton % 3;
    //NSLog(@"%d",b);
    
    if(b!=0)
        a += 1;
    
    int counter = 0;
    int y = 10;
    
    for (int j=0; j<a; j++) {
        int x = 10;
        int no;
        if (noOfButton-counter<3)
            no = b;
        else
            no = 3;
        
        for (int i=0; i<no; i++) {
           
            UIImage *img = [UIImage imageNamed:[self.imageList objectAtIndex:counter]];
            UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
            btn.frame = CGRectMake(x, y, 90, 100);
            btn.tag = counter;
            [btn setBackgroundImage:img forState:UIControlStateNormal];
            [btn addTarget:self action:@selector(isPressed:) forControlEvents:UIControlEventTouchUpInside];
            [self.scrollView addSubview:btn];
            x += 105;
            counter++;
        }
        y += 115;
    }
    
    self.scrollView.contentSize = CGSizeMake(scrollViewRect.size.width, y);
    
    //NSLog(@"%d",y);
    [self.view addSubview:self.scrollView];

    [self.spinner stopAnimating];
}


-(void)isPressed:(id)paraSender
{
    UIButton *no = (UIButton *) paraSender;
    //NSLog(@"%d",no.tag);
    detailGalleryVC = [[DetailGalleryViewController alloc] initWithNibName:@"DetailGalleryViewController" bundle:nil];
    detailGalleryVC.current = no.tag;
    [self.navigationController pushViewController:detailGalleryVC animated:YES];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
