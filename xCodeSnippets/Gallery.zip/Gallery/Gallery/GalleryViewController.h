//
//  GalleryViewController.h
//  Gallery
//
//  Created by Atif Saeed on 21/01/2014.
//  Copyright (c) 2014 Atif Saeed. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DetailGalleryViewController.h"

@interface GalleryViewController : UIViewController {
    DetailGalleryViewController *detailGalleryVC;
}

@property (strong, nonatomic) UIScrollView *scrollView;
@property (strong, nonatomic) NSArray *imageList;
@property (strong, nonatomic) UIActivityIndicatorView *spinner;

@end
