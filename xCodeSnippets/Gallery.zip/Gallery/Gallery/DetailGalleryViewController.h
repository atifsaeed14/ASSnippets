//
//  DetailGalleryViewController.h
//  Gallery
//
//  Created by Atif Saeed on 21/01/2014.
//  Copyright (c) 2014 Atif Saeed. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailGalleryViewController : UIViewController <UIScrollViewDelegate>

@property (assign, nonatomic) int previous;
@property (assign, nonatomic) int current;
@property (assign, nonatomic) int next;

@property (strong, nonatomic) NSArray *imageList;
@property (strong, nonatomic) UIImageView *imageViewer;
@property (strong,nonatomic) UIScrollView *scrollView;

@property (strong, nonatomic) UIActivityIndicatorView *spinner;

@end
