//
//  DetailGalleryViewController.m
//  Gallery
//
//  Created by Atif Saeed on 21/01/2014.
//  Copyright (c) 2014 Atif Saeed. All rights reserved.
//

#import "DetailGalleryViewController.h"
#import "ImageManager.h"

@interface DetailGalleryViewController () {
    
    UIImage *curImage;
    UIImage *preImage;
    UIImage *nexImage;
    
    UIImageView *curImageView;
    UIImageView *preImageView;
    UIImageView *nexImageView;
    
    CGRect curCGRect;
    CGRect preCGRect;
    CGRect nextCGRect;
    
    CGPoint translation;
    NSInteger lastContentOffset;
}
@end

@implementation DetailGalleryViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    /* UIActivity Indicator */
    self.spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    self.spinner.color = [UIColor redColor];
    [self.spinner setCenter:CGPointMake(160, 250)];
    [self.spinner startAnimating];
    [self.view addSubview:self.spinner];
    
    /* Invoking backgrounds methods, easy way to creaet threads without having to deal with threadas directly */
    [self performSelectorInBackground:@selector(loadImage) withObject:nil];
    
}

-(void)loadImage{
    
    self.imageList = [[ImageManager sharedManager] fetchingImages];
    self.title = [self.imageList objectAtIndex:self.current];
    
    if ([UIScreen mainScreen].bounds.size.height==480){
        self.scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 70, 320, 410)];
        self.scrollView.contentSize = CGSizeMake(320 * 3.0f, 410);
    } else if ([UIScreen mainScreen].bounds.size.height==568) {
        self.scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 70, 320, 498)];
        self.scrollView.contentSize = CGSizeMake(320 * 3.0f, 498);
    }
    
    self.scrollView.pagingEnabled = YES;
    [self.view addSubview:self.scrollView];
    _scrollView.delegate = self;
    curCGRect = self.view.bounds;
    
    curCGRect = CGRectMake(320, 0, curCGRect.size.width, curCGRect.size.height);
    preCGRect = CGRectMake(0, 0, curCGRect.size.width, curCGRect.size.height);
    nextCGRect = CGRectMake(640, 0, curCGRect.size.width, curCGRect.size.height);
    
    if([self.imageList objectAtIndex:self.current]==[self.imageList objectAtIndex:0]) {
        self.previous = [self.imageList count] - 1;
        self.next = self.current + 1;
    } else if ([self.imageList objectAtIndex:self.current]==[self.imageList lastObject]) {
        self.previous = self.current - 1;
        self.next = 0;
    } else {
        self.previous = self.current - 1;
        self.next = self.current + 1;
    }
    
    /* Current Image */
    curImage = [UIImage imageNamed:[self.imageList objectAtIndex:self.current]];
    curImageView = [self newImageViewWithImage:curImage frame:curCGRect];
    [self.scrollView addSubview:curImageView];
    [self.scrollView scrollRectToVisible:curCGRect animated:YES];
    
    /* Previous Image */
    preImage = [UIImage imageNamed:[self.imageList objectAtIndex:self.previous]];
    preImageView = [self newImageViewWithImage:preImage frame:preCGRect];
    [self.scrollView addSubview:preImageView];
    
    /* Next Image */
    nexImage = [UIImage imageNamed:[self.imageList objectAtIndex:self.next]];
    nexImageView = [self newImageViewWithImage:nexImage frame:nextCGRect];
    [self.scrollView addSubview:nexImageView];
    
}

- (UIImageView *)newImageViewWithImage:(UIImage *)paramImage frame:(CGRect)paramFrame
{
    UIImageView *result = [[UIImageView alloc] initWithFrame:paramFrame];
    result.contentMode = UIViewContentModeScaleToFill;
    result.image = paramImage;
    return result;
}


- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    
    self.title = [self.imageList objectAtIndex:self.current];
    
    
    
//    
//    
//    
//    if([self.imageList objectAtIndex:0]) {
//        
//        self.previous = self.current;
//        self.current++;
//        self.next = self.current + 1;
//
//        
//        
////        curImage = [UIImage imageNamed:[self.imageList objectAtIndex:self.current]];
////        imageViewRect = CGRectMake(0, 0, imageViewRect.size.width, imageViewRect.size.height);
////        curImageView = [self newImageViewWithImage:curImage frame:imageViewRect];
////        [self.scrollView addSubview:curImageView];
////        
////        /* Go to next page by moving the x position of the next image view */
////        self.next = self.current + 1;
////        nexImage = [UIImage imageNamed:[self.imageList objectAtIndex:self.next]];
////        imageViewRect = CGRectMake(320, 0, imageViewRect.size.width, imageViewRect.size.height);
////        nexImageView = [self newImageViewWithImage:nexImage frame:imageViewRect];
////        [self.scrollView addSubview:nexImageView];
//        
//    } else if ([self.imageList objectAtIndex:self.current]==[self.imageList lastObject]) {
//        
//        curImage = [UIImage imageNamed:[self.imageList objectAtIndex:self.current]];
//        //imageViewRect.origin.x += imageViewRect.size.width * 2;
//        imageViewRect = CGRectMake(640, 0, imageViewRect.size.width, imageViewRect.size.height);
//        curImageView = [self newImageViewWithImage:curImage frame:imageViewRect];
//        [self.scrollView addSubview:curImageView];
//        [self.scrollView scrollRectToVisible:imageViewRect animated:YES];
//        
//        /* Go to previous page by moving the x position of the next image view */
//        self.previous = self.current - 1;
//        preImage = [UIImage imageNamed:[self.imageList objectAtIndex:self.previous]];
//        imageViewRect = CGRectMake(320, 0, imageViewRect.size.width, imageViewRect.size.height);
//        preImageView = [self newImageViewWithImage:preImage frame:imageViewRect];
//        [self.scrollView addSubview:preImageView];
//        
//    }
//    
////    else {
////        
////        curImage = [UIImage imageNamed:[self.imageList objectAtIndex:self.current]];
////        imageViewRect = CGRectMake(320, 0, imageViewRect.size.width, imageViewRect.size.height);
////        curImageView = [self newImageViewWithImage:curImage frame:imageViewRect];
////        [self.scrollView addSubview:curImageView];
////        [self.scrollView scrollRectToVisible:imageViewRect animated:YES];
////        
////        /* Go to previous page by moving the x position of the next image view */
////        self.previous = self.current - 1;
////        preImage = [UIImage imageNamed:[self.imageList objectAtIndex:self.previous]];
////        imageViewRect = CGRectMake(0, 0, imageViewRect.size.width, imageViewRect.size.height);
////        preImageView = [self newImageViewWithImage:preImage frame:imageViewRect];
////        [self.scrollView addSubview:preImageView];
////        
////        /* Go to next page by moving the x position of the next image view */
////        self.next = self.current + 1;
////        nexImage = [UIImage imageNamed:[self.imageList objectAtIndex:self.next]];
////        imageViewRect = CGRectMake(640, 0, imageViewRect.size.width, imageViewRect.size.height);
////        nexImageView = [self newImageViewWithImage:nexImage frame:imageViewRect];
////        [self.scrollView addSubview:nexImageView];
////    }
//
//    
//    
//    
    
    
    
    
    
    
    
//    if([self.imageList objectAtIndex:self.current]==[self.imageList objectAtIndex:0]) {
//        
//    } else if ([self.imageList objectAtIndex:self.current]==[self.imageList lastObject]) {
//        imageViewRect.origin.x += imageViewRect.size.width * 2;
//        [self.scrollView scrollRectToVisible:imageViewRect animated:YES];
//        
//    } else {
//        imageViewRect.origin.x += imageViewRect.size.width;
//        [self.scrollView scrollRectToVisible:imageViewRect animated:YES];
//    }
//    
//    
//    
//    UIImageView *iPadImageView = [self newImageViewWithImage:iPad frame:imageViewRect];
//    [self.scrollView addSubview:iPadImageView];

//    UIImage *imgPreviouCurrent = [UIImage imageNamed:[self.imageList objectAtIndex:self.current]];
//    UIImage *imgCurrent = [UIImage imageNamed:[self.imageList objectAtIndex:self.current]];
//    UIImage *nextCurrent = [UIImage imageNamed:[self.imageList objectAtIndex:self.current]];
//    
//    CGRect imageViewRect = self.view.bounds;
//    
//    
//    NSLog(@"x %f",imageViewRect.origin.x);
//    NSLog(@"y %f",imageViewRect.origin.y);
//    NSLog(@"w %f",imageViewRect.size.width);
//    NSLog(@"h %f",imageViewRect.size.height);
//    
//    
//    NSLog(@"Current: %d",self.current);
//    if([self.imageList objectAtIndex:self.current]==[self.imageList objectAtIndex:0]) {
//        
//    } else if ([self.imageList objectAtIndex:self.current]==[self.imageList lastObject]) {
//        imageViewRect.origin.x += imageViewRect.size.width * 2;
//        [self.scrollView scrollRectToVisible:imageViewRect animated:YES];
//        
//    } else {
//        imageViewRect.origin.x += imageViewRect.size.width;
//        [self.scrollView scrollRectToVisible:imageViewRect animated:YES];
//    }
//    
//    NSLog(@"x %f",imageViewRect.origin.x);
//    NSLog(@"y %f",imageViewRect.origin.y);
//    NSLog(@"w %f",imageViewRect.size.width);
//    NSLog(@"h %f",imageViewRect.size.height);
//    
//    
//    
//    UIImageView *imgCurrentImageView = [self newImageViewWithImage:imgCurrent frame:imageViewRect];
//    [self.scrollView addSubview:imgCurrentImageView];

    
    //
    //    /* Go to next page by moving the x position of the next image view */
    //    imageViewRect.origin.y += imageViewRect.size.height;
    //    UIImageView *iPadImageView = [self newImageViewWithImage:iPad frame:imageViewRect];
    //    [self.scrollView addSubview:iPadImageView];
    //
    //    /* Go to next page by moving the x position of the next image view */
    //    imageViewRect.origin.y += imageViewRect.size.height;
    //    UIImageView *macBookAirImageView =
    //    [self newImageViewWithImage:macBookAir frame:imageViewRect];
    //    [self.scrollView addSubview:macBookAirImageView];

    
}


- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    lastContentOffset = scrollView.contentOffset.x;
    NSLog(@"%d", lastContentOffset);
}



- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    
    if ((lastContentOffset < (int)scrollView.contentOffset.x)||(lastContentOffset > (int)scrollView.contentOffset.x)) {
        
        //self.scrollView.contentOffset.x = 0;
        [self.scrollView setContentOffset:CGPointMake(0, 0) animated:YES];

        NSLog(@"x < %d", lastContentOffset);
        // moved right
        
        
        
//        if([self.imageList objectAtIndex:self.current]==[self.imageList objectAtIndex:0]) {
//            
//            self.previous = self.current;
//            self.current++;
//            self.next = self.current + 1;
        
//            
//        } else if ([self.imageList objectAtIndex:self.current]==[self.imageList lastObject]) {
//            self.previous = self.current - 1;
//            self.next = 0;
//        } else {
//            self.previous = self.current - 1;
//            self.next = self.current + 1;
//        }
        
        /* Current Image */
//        curImage = [UIImage imageNamed:[self.imageList objectAtIndex:self.current]];
//        curImageView = [self newImageViewWithImage:curImage frame:nextCGRect];
//        [self.scrollView addSubview:curImageView];
//        //[self.scrollView scrollRectToVisible:curCGRect animated:YES];
        
//        /* Previous Image */
//        preImage = [UIImage imageNamed:[self.imageList objectAtIndex:self.previous]];
//        preImageView = [self newImageViewWithImage:preImage frame:curCGRect];
//        [self.scrollView addSubview:preImageView];
//        
//        /* Next Image */
//        nexImage = [UIImage imageNamed:[self.imageList objectAtIndex:self.next]];
//        nexImageView = [self newImageViewWithImage:nexImage frame:curCGRect];
//        [self.scrollView addSubview:nexImageView];
        
        
    }
//    else if (lastContentOffset > (int)scrollView.contentOffset.x) {
//        NSLog(@"x > %d", lastContentOffset);
//        // moved left
//    }  
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
