//
//  FormViewController.h
//  3. To do list with multiple section
//
//  Created by Netsolace on 29/11/13.
//  Copyright (c) 2013 atif. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FormViewController : UIViewController <UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate>
@property (strong, nonatomic) IBOutlet UITableView *formUITable;
@property (strong, nonatomic) NSArray *items;
@end
