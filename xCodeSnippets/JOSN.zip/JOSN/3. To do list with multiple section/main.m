//
//  main.m
//  3. To do list with multiple section
//
//  Created by Netsolace on 20/11/13.
//  Copyright (c) 2013 atif. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
