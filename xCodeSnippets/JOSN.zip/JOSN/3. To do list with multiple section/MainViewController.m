//
//  MainViewController.m
//  3. To do list with multiple section
//
//  Created by Netsolace on 20/11/13.
//  Copyright (c) 2013 atif. All rights reserved.
//

#import "MainViewController.h"
#import "AddViewController.h"
#import "NSDate+add.h"

@interface MainViewController ()

@end

@implementation MainViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        /* title */
        self.title = @"To Do List";
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
   // NSTimeInterval oneYearTime = 365 * 24 * 60 * 60;
   // NSDate *todayDate = [NSDate date];
   
    //NSLog(@"toDate: %@",time);
    //NSDate *oneYearFromToday = [todayDate dateByAddingTimeInterval:oneYearTime];
    //NSLog(@"%@",oneYearFromToday);
    
    
    
    
    
    
    
    NSString *cDate = [NSString stringWithFormat:@"Thu, 06 Dec 2012 17:44:22 +0000"];
    
    NSDate *ddate = [[NSDate alloc] init];
    
    [ddate dateFormateChange:cDate];
    NSLog(@"cDate %@",ddate);
    
    
   
    
    
    /* The event starts from today, right now */
    //NSDate *startDate = [NSDate date];
    /* And the event ends this time tomorrow.
     24 hours, 60 minutes per hour and 60 seconds per minute
     hence 24 * 60 * 60 */
   // NSDate *endDate = [startDate
              //         dateByAddingTimeInterval:24 * 60 * 60];
    
    
    /* bar left button */
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemEdit target:self action:@selector(callEdit)];
    
    /* bar right button */
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"Add" style:UIBarButtonItemStylePlain target:self action:@selector(callAdd)];
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"etc" style:UIBarButtonItemStylePlain target:self action:@selector(callAdd)];
    
    /* list item */
    //self.items = @[@"fruit", @"vegetable"];
    //NSLog(@"%@",self.items);
    
    /* plist */
    NSError *error;
    
    /* ceate a list path */
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    
    /* get a path to your documents directory from the list */
    NSString *documentsDirectory = [paths objectAtIndex:0];
    
    /* get ful path */
    self.path = [documentsDirectory stringByAppendingPathComponent:@"data.plist"];
    //NSLog(@"Path: %@",self.path);
    
    /* or to get path using this */
    //NSString *dataFile = [NSHomeDirectory() stringByAppendingFormat:@"/Documents/"];
    //NSLog(@"dataFile: %@",dataFile);
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    /* check if file exit */
    if(![fileManager fileExistsAtPath:self.path])
    {
        /* get a path to your plist created before in bundle directory (by Xcode) */
        NSString *resPath = [[NSBundle mainBundle] pathForResource:@"data" ofType:@"plist"];
        //NSLog(@"resPath: %@",resPath);
        
        /* copy this plist to your documents directory */
        [fileManager copyItemAtPath:resPath toPath:self.path error:&error];
    }
    
    /* copy plist item into array */
    self.itemList = [[NSMutableArray alloc]initWithContentsOfFile:self.path];
    //NSLog(@"%@",self.itemList);
    
    /* UI Action Sheet */
    NSString *yes = @"Yes";
    NSString *no = @"No";
    self.actionSheet = [ [UIActionSheet alloc] initWithTitle:@"Do you want to delete this item." delegate:self
 cancelButtonTitle:@"Cancle" destructiveButtonTitle:no otherButtonTitles:yes, nil ];

}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSArray *secArray = [self.itemList objectAtIndex:section];
    NSInteger result = 0;
    if ([tableView isEqual:self.itemListTV])
    {
        switch (section) {
            case 0:
                result = [secArray count];
                break;

            case 1:
                result = [secArray count];
                break;
                
            case 2:
                result = [secArray count];
                break;
                
            default:
                break;
        }
    }
        
    return result;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    NSString *result = nil;
    switch (section) {
        case 0:
            result = @"AAAs";
            break;
            
        case 1:
            result = @"BBBs";
            break;
            
        case 2:
            result = @"CCCs";
            break;
            
        default:
            break;
    }
    return result;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [self.itemList count];    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   
    static NSString *cellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    }
    
    NSArray *secArray = [self.itemList objectAtIndex:indexPath.section];
    NSDictionary *rowDic = [secArray objectAtIndex:indexPath.row];
        
    id title = [rowDic objectForKey:@"title"];
    cell.textLabel.text = title;
    
    id state = [rowDic objectForKey:@"state"];
    BOOL success = [state boolValue];
    //NSLog(@"%d",success);
    if (success) {
        cell.accessoryType = UITableViewCellAccessoryCheckmark;
    }
    
    return cell;

}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [self.itemListTV cellForRowAtIndexPath:indexPath];
    NSMutableArray *secArray = [self.itemList objectAtIndex:indexPath.section];
    NSMutableDictionary *rowDic = [secArray objectAtIndex:indexPath.row];
    if (cell.accessoryType == UITableViewCellAccessoryCheckmark) {
        cell.accessoryType = UITableViewCellAccessoryNone;
        [rowDic setObject:@"NO" forKey:@"state"];
    } else {
        cell.accessoryType = UITableViewCellAccessoryCheckmark;
        [rowDic setObject:@"YES" forKey:@"state"];
    }
    
    [secArray replaceObjectAtIndex:indexPath.row withObject:rowDic];
    [self.itemList replaceObjectAtIndex:indexPath.section withObject:secArray];
    [self.itemList writeToFile:self.path atomically:YES];
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if(editingStyle == UITableViewCellEditingStyleDelete) {
        
        [self.actionSheet showInView:self.view];
        
        /* first remove this object from the source */
        NSMutableArray *secArray = [self.itemList objectAtIndex:indexPath.section];
        [secArray removeObjectAtIndex:indexPath.row];
        [self.itemList replaceObjectAtIndex:indexPath.section withObject:secArray];
        
        /* remove this from plist */
        [self.itemList writeToFile:self.path atomically:YES];
        
        /* then remove the associated cell from the Table View */
        [self.itemListTV deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationLeft];
    }
    
}

-(void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.itemListTV reloadData];
}

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
    NSString *buttonTitle = [actionSheet buttonTitleAtIndex:buttonIndex];
    if ([buttonTitle isEqualToString:@"Yes"]) {
        NSLog(@"Yes");
        
    }
    if ([buttonTitle isEqualToString:@"No"]) {
        NSLog(@"No");
        
    }
}

- (void)callAdd {
    addVC = [[AddViewController alloc] initWithNibName:@"AddViewController" bundle:nil];
    addVC.addItem = self.itemList;
    addVC.path = self.path;
    [self presentModalViewController:addVC animated:YES];

}

- (void)callEdit {
    self.itemListTV.editing = YES;
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(callCancel)];
}

- (void)callCancel {
    self.itemListTV.editing = NO;
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemEdit target:self action:@selector(callEdit)];
}

@end
