//
//  ImageScrollViewController.m
//  3. To do list with multiple section
//
//  Created by Netsolace on 22/11/13.
//  Copyright (c) 2013 atif. All rights reserved.
//

#import "ImageScrollViewController.h"

@interface ImageScrollViewController ()

@end

@implementation ImageScrollViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.title = @"Image Scroller";
        self.tabBarItem.image = [UIImage imageNamed:@""];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
//    UIImage *macBookAir = [UIImage imageNamed:@"MacBookAir.png"];
//    self.myImageView = [[UIImageView alloc] initWithImage:macBookAir];
//    self.myImageView.center = self.view.center;
//    [self.view addSubview:self.myImageView];
    
    
//    UIImage *imageToLoad = [UIImage imageNamed:@"MacBookAir.png"];
//    self.myImageView = [[UIImageView alloc] initWithImage:imageToLoad];
//    self.usingCodeSV = [[UIScrollView alloc] initWithFrame:self.view.bounds];
//    [self.usingCodeSV addSubview:self.myImageView];
//    self.usingCodeSV.contentSize = self.myImageView.bounds.size;
//    [self.view addSubview:self.usingCodeSV];
    
    UIImage *iPhone = [UIImage imageNamed:@"iPhone.png"];
    UIImage *iPad = [UIImage imageNamed:@"iPad.png"];
    UIImage *macBookAir = [UIImage imageNamed:@"MacBookAir.png"];
    CGRect scrollViewRect = self.view.bounds;
    
    self.myScrollView = [[UIScrollView alloc] initWithFrame:scrollViewRect];
    self.myScrollView.pagingEnabled = YES;
    self.myScrollView.contentSize = CGSizeMake(scrollViewRect.size.width, scrollViewRect.size.height * 3.0f);
    [self.view addSubview:self.myScrollView];
    
    CGRect imageViewRect = self.view.bounds;
    
    UIImageView *iPhoneImageView = [self newImageViewWithImage:iPhone
                                    frame:imageViewRect];
    
    [self.myScrollView addSubview:iPhoneImageView];
    
    
    /* Go to next page by moving the x position of the next image view */
    imageViewRect.origin.y += imageViewRect.size.height;
    UIImageView *iPadImageView = [self newImageViewWithImage:iPad frame:imageViewRect];
    [self.myScrollView addSubview:iPadImageView];
                                                                                                           
    /* Go to next page by moving the x position of the next image view */
    imageViewRect.origin.y += imageViewRect.size.height;
    UIImageView *macBookAirImageView =
    [self newImageViewWithImage:macBookAir frame:imageViewRect];
    [self.myScrollView addSubview:macBookAirImageView];
    
}

- (UIImageView *) newImageViewWithImage:(UIImage *)paramImage frame:(CGRect)paramFrame
{
    UIImageView *result = [[UIImageView alloc] initWithFrame:paramFrame];
    result.contentMode = UIViewContentModeScaleAspectFit;
    result.image = paramImage;
    return result;
}

                  
                  
- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
