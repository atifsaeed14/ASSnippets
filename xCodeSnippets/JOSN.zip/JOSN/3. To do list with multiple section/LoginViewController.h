//
//  LoginViewController.h
//  3. To do list with multiple section
//
//  Created by Netsolace on 22/11/13.
//  Copyright (c) 2013 atif. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>

//@property (strong, nonatomic) IBOutlet UIImageView *loginImage;

@property (strong, nonatomic) IBOutlet UITableView *staticTable;

@property (strong, nonatomic) NSMutableArray *mainArray;

- (void)upTapped:(id)paramSender;

//-(void)upTapped;
//-(void)downTapped;
@end
