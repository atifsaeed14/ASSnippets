//
//  JSONManager.h
//  3. To do list with multiple section
//
//  Created by Atif Saeed on 20/01/2014.
//  Copyright (c) 2014 atif. All rights reserved.
//

#import <Foundation/Foundation.h>

/* delegate methods for JSON */
@protocol JSONDelegate <NSObject>
- (void)didReceivedJSONData:(NSArray *)jsonData;
- (void)fetchingJSONDataFailedWithError:(NSString *)errorMessage;
@end

@interface JSONManager : NSObject {
    id<JSONDelegate> jDelegate;
}

+ (JSONManager *)sharedManager;
@property (strong, nonatomic) NSString *errorMessage;
@property (strong, nonatomic) NSDictionary *jsonDictionary;
@property (strong, nonatomic) NSArray *jsonArray;
-(void)loadJosnDataWithDelegate:(id<JSONDelegate>)delegate;

@end
