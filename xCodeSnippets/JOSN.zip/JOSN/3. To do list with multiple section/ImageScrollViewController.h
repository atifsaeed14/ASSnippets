//
//  ImageScrollViewController.h
//  3. To do list with multiple section
//
//  Created by Netsolace on 22/11/13.
//  Copyright (c) 2013 atif. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ImageScrollViewController : UIViewController <UIScrollViewDelegate>

@property (strong,nonatomic) UIImageView *myImageView;
@property (strong,nonatomic) UIScrollView *myScrollView;




@end
