//
//  JSONManager.m
//  3. To do list with multiple section
//
//  Created by Atif Saeed on 20/01/2014.
//  Copyright (c) 2014 atif. All rights reserved.
//

#import "JSONManager.h"

static JSONManager *sharedManager = nil;

@implementation JSONManager

+ (JSONManager *) sharedManager
{
    if(sharedManager == nil)
        sharedManager = [[self alloc] init];
    return sharedManager;
}

- (id) init
{
    self = [super init];
    if (self)
    {
        self.errorMessage = [[NSString alloc] init];
    }
    return self;
}

#pragma mark - Json Data manager methods
-(void)loadJosnDataWithDelegate:(id<JSONDelegate>)delegate
{
    jDelegate = delegate;
    
    /* JSON Parsing */
    NSError *error = nil;
    NSURL *url = [NSURL URLWithString:@"https://itunes.apple.com/search?term=games&entity=software"];
    //NSString *urlAsString = [NSString stringWithFormat:@"https://api.meetup.com/2/groups?lat=%f&lon=%f&page=%d&key=%@", coordinate.latitude, coordinate.longitude, PAGE_COUNT, API_KEY];
    NSData *jsonData = [NSData dataWithContentsOfURL:url options:0 error:&error];
    
    if(error==nil) {
        NSError *jsonError = nil;
        id jsonObject = [NSJSONSerialization JSONObjectWithData:jsonData options:kNilOptions error:&jsonError];
        
        if(jsonError==nil) {
            if ([jsonObject isKindOfClass:[NSArray class]]) {
                NSLog(@"its an array!");
                //NSArray *jsonArray = (NSArray *)jsonObject;
                //NSLog(@"jsonArray - %@",jsonArray);
            } else {
                NSLog(@"its probably a dictionary");
                self.jsonDictionary = (NSDictionary *)jsonObject;
            //NSLog(@"jsonDictionary - %@",jsonDictionary);
            }
        
            self.jsonArray = [self.jsonDictionary objectForKey:@"results"];
            //NSLog(@"%@",self.jsonArray);
            
            if([self.jsonArray count] > 0){
                //[jDelegate didReceivedJSONData:self.jsonArray];
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    if([jDelegate respondsToSelector:@selector(didReceivedJSONData:)])
                    {
                        [jDelegate didReceivedJSONData:self.jsonArray];
                    }
                });
                
            } else {
                self.errorMessage = @"Not Available";
                dispatch_async(dispatch_get_main_queue(), ^{
                    if([jDelegate respondsToSelector:@selector(fetchingJSONDataFailedWithError:)])
                    {
                        [jDelegate fetchingJSONDataFailedWithError:self.errorMessage];
                    }
                });
                NSLog(@"Not Available");
            }
            
        } else {
            self.errorMessage = @"Domain Error (404)";
            dispatch_async(dispatch_get_main_queue(), ^{
                if([jDelegate respondsToSelector:@selector(fetchingJSONDataFailedWithError:)])
                {
                    [jDelegate fetchingJSONDataFailedWithError:self.errorMessage];
                }
            });
            NSLog(@"jsonError: %@", jsonError);
        }
    } else {
        self.errorMessage = @"Domain Error (404)";
        dispatch_async(dispatch_get_main_queue(), ^{
            if([jDelegate respondsToSelector:@selector(fetchingJSONDataFailedWithError:)])
            {
                [jDelegate fetchingJSONDataFailedWithError:self.errorMessage];
            }
        });
        NSLog(@"Error: %@", error);
    }
    
}

@end
