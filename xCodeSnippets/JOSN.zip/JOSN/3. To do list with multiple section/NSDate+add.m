//
//  NSDate+add.m
//  3. To do list with multiple section
//
//  Created by Netsolace on 3/12/13.
//  Copyright (c) 2013 atif. All rights reserved.
//

#import "NSDate+add.h"

@implementation NSDate (add)

-(NSDate *)dateFormateChange:(NSString *)date{
    
    
    
    // NSString *str = @"Thu, 06 Dec 2012 17:44:22 +0000";
    //    NSString *str =[yourStringDate stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    //
    //    str =[str stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    //
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"EEE, dd MMM yyyy HH:mm:ss z"];
    
    //[dateFormatter setDateFormat:@"EEEE,LLLL dd,yyyy z"];
    //[dateFormatter setDateFormat:@"EEEE,LLLL dd,yyyy"];
    
    NSDate *tdate = [dateFormatter dateFromString: date];
    NSLog(@"tdate: %@",tdate);
    
    
    //NSDate *d = [dateFormatter d]
    
    dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"EEEE,LLLL dd,yyyy"];
    
    NSString *convertedString = [dateFormatter stringFromDate:tdate];
    NSLog(@"Converted String : %@",convertedString);
    
    NSDate *covertedNSDate = [dateFormatter dateFromString:convertedString];
    
    NSLog(@"covertedNSDate: %@",covertedNSDate);
    
    NSString *datestr = [NSString stringWithFormat:@"Thu, 06 Dec 2012 17:44:22 +0000"];
   // NSString *datestr = @"2013-08-06T03:51:54+00:00";
    NSDateFormatter *dformat = [[NSDateFormatter alloc]init];
    [dformat setDateFormat:@"yyyy-MM-dd'T'HH:mm:ssz"];
    NSDate *datee = [dformat dateFromString:datestr];
    NSLog(@"%@",datee);
    
    
    
    
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"yyyy-MM-dd"];
    
    NSDateFormatter *timeFormat = [[NSDateFormatter alloc] init];
    [timeFormat setDateFormat:@"HH:mm:ss"];
    
    NSDate *now = [[NSDate alloc] init];
    
    NSString *theDate = [dateFormat stringFromDate:now];
    NSString *theTime = [timeFormat stringFromDate:now];
    
    NSLog(@"\n"
          "theDate: |%@| \n"
          "theTime: |%@| \n"
          , theDate, theTime);
    
    
    
    
    //    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    //    NSDate *nowDate = [[NSDate alloc] init];
    //    [formatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
    //    NSString *ddate = [date stringByReplacingOccurrencesOfString:@"+0000" withString:@""];
    //    nowDate = [formatter dateFromString:ddate];
    //     NSLog(@"date============================>>>>>>>>>>>>>>> : %@", nowDate);
    //    
    return covertedNSDate;
}


@end
