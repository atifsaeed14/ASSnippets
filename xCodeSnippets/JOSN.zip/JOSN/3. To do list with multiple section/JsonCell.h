//
//  JsonCell.h
//  3. To do list with multiple section
//
//  Created by Netsolace on 26/11/13.
//  Copyright (c) 2013 atif. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JsonCell : UITableViewCell

@property (nonatomic, strong) UILabel *price;
//@property (nonatomic, strong) UIImageView *image;
//@property (nonatomic, strong) UILabel *title;
//@property (nonatomic, strong) UILabel *subTitle;

@end
