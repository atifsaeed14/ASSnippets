//
//  AddViewController.h
//  3. To do list with multiple section
//
//  Created by Netsolace on 21/11/13.
//  Copyright (c) 2013 atif. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddViewController : UIViewController <UITextFieldDelegate, UIPickerViewDelegate,UIPickerViewDataSource,UIAlertViewDelegate>

@property (strong, nonatomic) NSMutableArray *addItem;
@property (strong, nonatomic) NSString *path;
@property (strong, nonatomic) IBOutlet UITextField *itemName;
@property (strong, nonatomic) IBOutlet UILabel *addMessage;
@property (strong, nonatomic) IBOutlet UIPickerView *itemSection;
@property (strong, nonatomic) NSArray *sectionHeader;
-(IBAction)callBack:(UIButton *)sender;
-(IBAction)callAdd:(UIButton *)sender;

@property (strong, nonatomic) UIAlertView *alertView;

-(NSString *)yesButtonTitle;
-(NSString *)noButtonTitle;




@end
