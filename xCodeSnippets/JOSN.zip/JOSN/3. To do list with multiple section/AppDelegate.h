
//  AppDelegate.h
//  3. To do list with multiple section
//
//  Created by Netsolace on 20/11/13.
//  Copyright (c) 2013 atif. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MainViewController, LoginViewController, ImageScrollViewController, JsonViewController, FormViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong,nonatomic) UIWindow *window;
@property (strong,nonatomic) MainViewController *mainVC;
@property (strong,nonatomic) UINavigationController *mainNC;
@property (strong,nonatomic) LoginViewController *loginVC;
@property (strong,nonatomic) ImageScrollViewController *imageScrollVC;
@property (strong,nonatomic) JsonViewController *jsonVC;
@property (strong,nonatomic) UINavigationController *jsonNC;

@property (strong,nonatomic) FormViewController *formVC;
@property (strong, nonatomic) UITabBarController *uiTBC;

@end
