//
//  JsonViewController.h
//  3. To do list with multiple section
//
//  Created by Netsolace on 25/11/13.
//  Copyright (c) 2013 atif. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "JSONManager.h"

@class MBProgressHUD;

@interface JsonViewController : UIViewController <UITableViewDataSource, UITableViewDelegate, JSONDelegate> {
    MBProgressHUD *HUD;
}

@property (strong,nonatomic) IBOutlet UITableView *jsonTV;
@property (strong,nonatomic) NSArray *item;
@property (strong,nonatomic) NSDictionary *jsonDictionary;
@property (strong,nonatomic) NSArray *jsonArray;
@property (strong,nonatomic) UILabel *price;

@property (strong,nonatomic) UIActivityIndicatorView *spinner;
@end
