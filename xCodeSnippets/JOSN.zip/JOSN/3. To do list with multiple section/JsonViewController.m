//
//  JsonViewController.m
//  3. To do list with multiple section
//
//  Created by Netsolace on 25/11/13.
//  Copyright (c) 2013 atif. All rights reserved.
//

#import "JsonViewController.h"
#import "JsonCell.h"
#import "MBProgressHUD.h"
#import "JSONManager.h"

@interface JsonViewController ()

@end

@implementation JsonViewController
@synthesize jsonTV;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.title = @"JSON";
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.item = @[@"Fruit", @"Vegetable"];
   
    /* Invoking backgrounds methods, easy way to creaet threads without having to deal with threadas directly */
    //[self performSelectorInBackground:@selector(loadJosnData) withObject:nil];
    
    /* spinner work fine  */
    self.spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    //ai.center = self.view.center;
    [self.spinner setCenter:CGPointMake(160, 170)];
    self.spinner.color = [UIColor blackColor];
    [self.spinner startAnimating];
    [self.view addSubview:self.spinner];
    //[self.view bringSubviewToFront:ai];
   
    
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_async(queue, ^{
        [[JSONManager sharedManager] loadJosnDataWithDelegate:self];
    });
    
    /*  HUD = [[MBProgressHUD alloc] initWithView:self.view];
     
     
     HUD = [[MBProgressHUD alloc] initWithView:self.view];
     [self.view addSubview:HUD];
     [HUD show:YES];
     
     
     UIActivityIndicatorView *ai = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite];
     ai.center = self.view.center;
     [ai setColor:[UIColor orangeColor]];
     [ai startAnimating];
     [self.view addSubview:ai];
     
    
   
    HUD = [[MBProgressHUD alloc] initWithView:self.view];
    HUD.labelText = @"Load Data";
    //HUD.detailsLabelText = @"Just relax";
    HUD.mode = MBProgressHUDAnimationZoom;
    //HUD.mode = MBProgressHUDModeAnnularDeterminate
    [self.view addSubview:HUD];
    
    //[HUD showWhileExecuting:@selector(doSomeFunkyStuff) onTarget:self withObject:nil animated:YES];
    
    [HUD showWhileExecuting:@selector(doSomeFunkyStuff) onTarget:self withObject:nil animated:YES];
    //        self.spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    //        [self.spinner setCenter:CGPointMake(150/2.0, 200/2.0)]; // I do this because I'm in landscape mode
    //        [self.view addSubview:self.spinner]; // spinner is not visible until started
    //
    //        [self.spinner startAnimating];

    
}

- (void)doSomeFunkyStuff {
//	float progress = 0.0;
//    
//	while (progress < 1.0) {
//		progress += 0.01;
//		HUD.progress = progress;
//		usleep(50000);
//	}
    
    
    
    
     JSON Parsing *
    NSError *error = nil;
    NSURL *url = [NSURL URLWithString:@"https://itunes.apple.com/search?term=games&entity=software"];
    NSData *jsonData = [NSData dataWithContentsOfURL:url options:0 error:&error];
    
    NSError *jsonError = nil;
    id jsonObject = [NSJSONSerialization JSONObjectWithData:jsonData options:kNilOptions error:&jsonError];
    
    if ([jsonObject isKindOfClass:[NSArray class]]) {
        NSLog(@"its an array!");
        //NSArray *jsonArray = (NSArray *)jsonObject;
        //NSLog(@"jsonArray - %@",jsonArray);
    }
    else {
        NSLog(@"its probably a dictionary");
        self.jsonDictionary = (NSDictionary *)jsonObject;
        //NSLog(@"jsonDictionary - %@",jsonDictionary);
    }
    
    self.jsonArray = [self.jsonDictionary objectForKey:@"results"];
    //NSLog(@"%@",self.jsonArray);
    
    [self.jsonTV reloadData];
    
    
}
 */
}

-(void)loadJosnData
{
    @autoreleasepool {
        
                
        /* JSON Parsing */
        NSError *error = nil;
        NSURL *url = [NSURL URLWithString:@"https://itunes.apple.com/search?term=games&entity=software"];
        NSData *jsonData = [NSData dataWithContentsOfURL:url options:0 error:&error];
        
        NSError *jsonError = nil;
        id jsonObject = [NSJSONSerialization JSONObjectWithData:jsonData options:kNilOptions error:&jsonError];
        
        if ([jsonObject isKindOfClass:[NSArray class]]) {
            NSLog(@"its an array!");
            //NSArray *jsonArray = (NSArray *)jsonObject;
            //NSLog(@"jsonArray - %@",jsonArray);
        }
        else {
            NSLog(@"its probably a dictionary");
            self.jsonDictionary = (NSDictionary *)jsonObject;
            //NSLog(@"jsonDictionary - %@",jsonDictionary);
        }
        
        self.jsonArray = [self.jsonDictionary objectForKey:@"results"];
        //NSLog(@"%@",self.jsonArray);
        
        [self.jsonTV reloadData];
        
        [self.spinner stopAnimating];
    }

}


#pragma mark - Json Delegate Function

- (void)didReceivedJSONData:(NSArray *)jsonData {
    self.jsonArray = jsonData;
    [self.jsonTV reloadData];
    [self.spinner stopAnimating];
}

- (void)fetchingJSONDataFailedWithError:(NSString *)errorMessage {
    [self.spinner stopAnimating];
    [self showAlertWithMessage:errorMessage];
}


- (void)viewDidUnload {
    [self setJsonTV:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.jsonArray count];
    //return 3;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *cellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if(cell==nil){
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentifier];

        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(260, 10, 40, 30)];
        label.tag = 100;
        label.textAlignment = UITextAlignmentCenter;
        [cell addSubview:label];

    }

    

    
    /* when using custom cell class like in jsonCell.h */
    
//    // Similar to UITableViewCell, but
//    JsonCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
//    if (cell == nil) {
//        cell = [[JsonCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentifier];
//    
//    
//    }
    
    NSDictionary *temDic = [self.jsonArray objectAtIndex:indexPath.row];
    cell.textLabel.text = [temDic objectForKey:@"trackName"];
    
    //self.price.text = [temDic objectForKey:@"formattedPrice"];
    
    
    UILabel *label = (UILabel *)[cell viewWithTag:100];
    //self.label.text = [temDic objectForKey:@"formattedPrice"];
    label.text = [NSString stringWithFormat:@"%d",indexPath.row];

    /* image form server */
    NSArray *temArray = [temDic objectForKey:@"genres"];
    NSString *str = [temArray componentsJoinedByString:@" - "];
    cell.detailTextLabel.text = str;
    
    
    UIActivityIndicatorView *spinnerOnCell = [[UIActivityIndicatorView alloc]
                                         initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    UIImage *spacer = [UIImage imageNamed:@"transparent.png"];
    spinnerOnCell.color = [UIColor blackColor];
    cell.imageView.image = spacer;
    [spinnerOnCell setCenter:CGPointMake(30,30)];
    
    [cell.imageView addSubview:spinnerOnCell];
    [spinnerOnCell startAnimating];
    
    
    dispatch_queue_t img_queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_async(img_queue, ^{
        
        NSURL *imageURL = [NSURL URLWithString:[temDic objectForKey:@"artworkUrl60"]];
        NSError *error = nil;
        NSData *imageData = [NSData dataWithContentsOfURL:imageURL options:0 error:&error];
        
        /* save image to user memory
         NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
         NSString *path = [[paths objectAtIndex:0] stringByAppendingPathComponent:@"image.png"];
         [image writeToFile:path options:0 error:&error];
         UIImage *img = [UIImage imageWithData:image]; */
        
        
        if(!error && imageData && [imageData length] > 0) {
            dispatch_async(dispatch_get_main_queue(), ^{
               cell.imageView.image = [UIImage imageWithData:imageData];
               [spinnerOnCell stopAnimating];
            });
        }
    });
    
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 70;
}

-(void) showAlertWithMessage:(NSString*)message
{
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"testing" message:message delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [alertView show];
}

@end
