//
//  FormViewController.m
//  3. To do list with multiple section
//
//  Created by Netsolace on 29/11/13.
//  Copyright (c) 2013 atif. All rights reserved.
//

#import "FormViewController.h"

@interface FormViewController ()

@end

@implementation FormViewController
@synthesize formUITable;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.title = @"Form";
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.items = [[NSArray alloc] init];
    self.items = @[@"Atif", @"Abdul Basit"];
}

- (void)viewDidUnload
{
    [self setFormUITable:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
    
    
    /* keypad hidden */
    
   
    
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    //return [self.items count];
    return 5;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell==nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        
        
        if(indexPath.row<4) {
            UITextField *testField = [[UITextField alloc] initWithFrame:CGRectMake(10, 5, 300, 35)];
            testField.tag = 10;
                testField.borderStyle = UITextBorderStyleRoundedRect;
            testField.textColor = [UIColor blackColor];
            testField.adjustsFontSizeToFitWidth = YES;
            testField.clearsOnBeginEditing = NO;
            testField.backgroundColor = [UIColor whiteColor];
            testField.autocorrectionType = UITextAutocorrectionTypeNo; // no auto correction support
            testField.autocapitalizationType = UITextAutocapitalizationTypeNone; // no auto capitalization support
            testField.textAlignment = UITextAlignmentLeft;
            testField.clearButtonMode = UITextFieldViewModeNever; // no clear 'x' button to the right
            [testField setEnabled: YES];
            testField.delegate = self;
            [cell addSubview:testField];
        
        }
            
        

        
        if (indexPath.row == 4) {
            UIButton *btnCancle = [UIButton buttonWithType:UIButtonTypeRoundedRect];
            btnCancle.frame = CGRectMake(50, 5, 100, 35);
            btnCancle.tag = 20;
          //  btnCancle.backgroundColor = [uicolor r=]
            [btnCancle setTitle:@"Cancel" forState:UIControlStateNormal];
            [cell addSubview:btnCancle];
            
            
            UIButton *btnSign = [UIButton buttonWithType:UIButtonTypeRoundedRect];
            btnSign.frame = CGRectMake(170, 5, 100, 35);
            btnSign.tag = 30;
            [btnSign setTitle:@"SignUp" forState:UIControlStateNormal];
            [cell addSubview:btnSign];
        }
          
//        if ([indexPath row] == 0) {
//            playerTextField.placeholder = @"example@gmail.com";
//            playerTextField.keyboardType = UIKeyboardTypeEmailAddress;
//            playerTextField.returnKeyType = UIReturnKeyNext;
//        }
        
    }
    
    
    UITextField *temField = (UITextField *)[cell viewWithTag:10];
    switch (indexPath.row) {
        case 0:
            temField.placeholder = @"Name";
            break;
        case 1:
            temField.placeholder = @"UserName";
            break;
        case 2:
            temField.placeholder = @"Email";
            temField.keyboardType = UIKeyboardTypeEmailAddress;
            break;
        case 3:
            temField.placeholder = @"Password";
            temField.keyboardType = UIKeyboardTypeDefault;
            temField.returnKeyType = UIReturnKeyDone;
            break;
        default:
            break;
    }
    
//    if (indexPath.row == 4) {
//        UIButton *btnCan = (UIButton *)[cell viewWithTag:20];
//        //[btnCan addTarget:self action:@selector(abc) forControlEvents:UIControlEventTouchDragInside];
//    }
    
    //cell.textLabel.text = [self.items objectAtIndex:indexPath.row];
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
//    UITableViewCell *cell = [self tableView:tableView cellForRowAtIndexPath:indexPath];
//    UITextField *textField;
//    for (UIView *view in [cell subviews]) {
//        if ([view isMemberOfClass:[UITextField class]]) {
//            textField = ((UITextField *)view);
//        }
//    }
//    
//    [textField becomeFirstResponder];
    
//    UITableViewCell *cell = [self tableView:tableView cellForRowAtIndexPath:indexPath];
//    
//    UITextField *test = (UITextField *)[cell viewWithTag:20];
//    test.delegate = self;
    
}



- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return NO;
}


@end
