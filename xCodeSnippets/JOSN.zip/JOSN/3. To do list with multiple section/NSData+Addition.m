//
//  NSData+Addition.m
//  3. To do list with multiple section
//
//  Created by Netsolace on 3/12/13.
//  Copyright (c) 2013 atif. All rights reserved.
//

#import "NSData+Addition.h"

@implementation NSData (Addition)


-(NSDate *)dateFormateChange:(NSString *)date{
    

    
   // NSString *str = @"Thu, 06 Dec 2012 17:44:22 +0000";
//    NSString *str =[yourStringDate stringByReplacingOccurrencesOfString:@"\n" withString:@""];
//    
//    str =[str stringByReplacingOccurrencesOfString:@"\t" withString:@""];
//   
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"EEE, dd MMM yyyy HH:mm:ss z"];

    NSDate *tdate = [dateFormatter dateFromString: date];
    NSLog(@"tdate: %@",tdate);
    
    dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"EEEE,LLLL dd,yyyy"];
    
    NSString *convertedString = [dateFormatter stringFromDate:tdate];
    NSLog(@"Converted String : %@",convertedString);
    
    NSDate *covertedNSDate = [dateFormatter dateFromString:convertedString];
    
    NSLog(@"%@",covertedNSDate);
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    NSDate *nowDate = [[NSDate alloc] init];
    [formatter setDateFormat:@"yyyy-MM-dd'T'HH:mm:ss"];
    NSString *ddate = [date stringByReplacingOccurrencesOfString:@"+0000" withString:@""];
    nowDate = [formatter dateFromString:ddate];
     NSLog(@"date============================>>>>>>>>>>>>>>> : %@", nowDate);
//
    return covertedNSDate;
}
@end
