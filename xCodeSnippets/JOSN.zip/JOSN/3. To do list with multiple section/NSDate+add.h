//
//  NSDate+add.h
//  3. To do list with multiple section
//
//  Created by Netsolace on 3/12/13.
//  Copyright (c) 2013 atif. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDate (add)
-(NSDate *)dateFormateChange:(NSString *)date;

@end
