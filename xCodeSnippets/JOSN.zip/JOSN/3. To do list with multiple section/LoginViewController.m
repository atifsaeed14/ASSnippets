//
//  LoginViewController.m
//  3. To do list with multiple section
//
//  Created by Netsolace on 22/11/13.
//  Copyright (c) 2013 atif. All rights reserved.
//

#import "LoginViewController.h"

@interface LoginViewController ()

@end

@implementation LoginViewController
@synthesize staticTable;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.title = @"Login";
        self.tabBarItem.image = [UIImage imageNamed:@""];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    NSUInteger outsideVariable = 10;
    NSMutableArray *array = [[NSMutableArray alloc] initWithObjects:@"obj1",
                             @"obj2", nil];
    [array sortUsingComparator:^NSComparisonResult(id obj1, id obj2) {
        NSUInteger insideVariable = 20;
        NSLog(@"Outside variable = %lu", (unsigned long)outsideVariable);
        NSLog(@"Inside variable = %lu", (unsigned long)insideVariable); /* Return value for the block object */
        return NSOrderedSame; }];
    
    
    
    
    //int answer = arc4random();
    //answer = answer%100 + 1; // get range from 1 to 100
    //NSLog(@"The random value is %i", answer);
    
    /* while create object * has been use meaning "point to"*/
    //NSString *name = @"Mike";
    
    // Objects in Objective-C were prefixed with “NS” — short for NeXTSTEP
    
    
    
    
//    NSMutableArray *array = [NSMutableArray array];
//    for( int i = 0; i < 3; ++i )
//    {
//        [array addObject:[NSNumber numberWithInt:i]];
//    }
    
    //int firstValue = [[array objectAtIndex:0] intValue];
    
    
//    NSArray *keys = [NSArray arrayWithObjects:@"1", @"2", @"3" nil];
//    NSArray *objects = [NSArray arrayWithObjects:@"Atif Saeed", @"Abdul Basit Saeed", @"Hashir Saeed", nil];
//    NSDictionary *dictionary = [NSDictionary dictionaryWithObjects:objects
//                                                           forKeys:keys];
//    NSLog(@"%@",dictionary);

    
    
    self.mainArray = [[NSMutableArray alloc] init];
    
    /* dictionary object */
    NSMutableDictionary *temDic = [[NSMutableDictionary alloc] init];
    [temDic setObject:@"Atif Saeed" forKey:@"name"];
    [temDic setObject:@83 forKey:@"value"];
    
    /* add dictionary object to array */
    [self.mainArray addObject:temDic];
    
    temDic = [@{@"name":@"Anthony", @"value":@0} mutableCopy];
    [self.mainArray addObject:temDic];
    
    temDic = [@{@"name":@"Abdul Basit Saeed", @"value":@45} mutableCopy];
    [self.mainArray addObject:temDic];
    
    temDic =  [@{@"name":@"Hashir Saeed", @"value":@54} mutableCopy];
    [self.mainArray addObject:temDic];
    
    //NSLog(@"%@",self.mainArray);
    
}

- (void)viewDidUnload
{
    [self setStaticTable:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.mainArray count];
}


- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    
//    if ((indexPath.row % 2) == 1) {
//        cell.backgroundColor = UIColorFromRGB(0xEDEDED);
//        cell.textLabel.backgroundColor = UIColorFromRGB(0xEDEDED);
//        cell.selectionStyle = UITableViewCellSelectionStyleGray;
//    }
//    else
//    {
//        cell.backgroundColor = [UIColor whiteColor];
//        cell.selectionStyle = UITableViewCellSelectionStyleGray;
//    }
    
    
    
    UIColor *color = ((indexPath.row % 2) == 0) ? [UIColor colorWithRed:255.0/255 green:255.0/255 blue:145.0/255 alpha:1] : [UIColor clearColor];
    cell.backgroundColor = color;
    
    
    cell.backgroundColor = [UIColor colorWithRed:0 green:0.188235 blue:0.313725 alpha:1];

}


// Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
// Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)




/* Stepper */
//- (void)stepperValueChanged:(UIStepper *)sender
//{
//    int value = [sender value];
//    //NSLog(@"%d",(int)value);
//    NSString *strValue = [[NSString alloc] initWithFormat:@"%d",value];
//    
//    UITableViewCell *cell = (UITableViewCell *)[sender superview];
//    /* assuming your view controller is a subclass of UITableViewController, for example. */
//    NSIndexPath *indexPath = [self.staticTable indexPathForCell:cell];
//    
//    //NSLog(@"%d", sender.tag);
//    //NSLog(@"%d, %d",indexPath.row, indexPath.section);
//    
//    NSMutableDictionary *temDic = [self.mainArray objectAtIndex:indexPath.row];
//    [temDic setObject:strValue forKey:@"value"];
//    
//    [self.mainArray replaceObjectAtIndex:indexPath.row withObject:temDic];
//    
//    //NSLog(@"%@",temDic);
//    
//    [self.staticTable reloadData];
//}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if(cell==nil)
    {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        
        /* up button */
        UIImage *upImage = [UIImage imageNamed:@"up.jpeg"];
        UIButton *up =[UIButton buttonWithType:UIButtonTypeCustom];
        up.frame = CGRectMake(280, 5, 20, 15);
        up.tag = 100;
        [up setBackgroundImage:upImage forState:UIControlStateNormal];
        //[up setTitle:@"Normal" forState:UIControlStateNormal];
        [cell addSubview:up];
        
        /* down button */
        UIImage *downImage = [UIImage imageNamed:@"down.jpeg"];
        UIButton *down = [UIButton buttonWithType:UIButtonTypeCustom];
        down.frame = CGRectMake(280, 25, 20, 15);
        down.tag = 50;
        [down setBackgroundImage:downImage forState:UIControlStateNormal];
        [cell addSubview:down];
        
        /* Stepper */
//        UIStepper *stepper = [[UIStepper alloc] initWithFrame:CGRectMake(220, 10, 100, 10)];
//        stepper.tag = 10;
//        [cell addSubview:stepper];

       // UIStepper* stepper = [[UIStepper alloc] init];
        //stepper.frame = CGRectMake(220, 10, 100, 10);
        //[cell.contentView addSubview: stepper];
        
        
        
    }
    
    NSDictionary *tem = [self.mainArray objectAtIndex:indexPath.row];
    
    NSString *str = [[NSString alloc] initWithFormat:@"%@ (%@)",[tem objectForKey:@"name"],[tem objectForKey:@"value"] ];
    
    cell.textLabel.text = str;
    
    //cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    
    
    /* Stepper */
//    UIStepper *stp = (UIStepper *)[cell viewWithTag:10];
//    stp.value = [[tem objectForKey:@"value"] integerValue];
//    [stp addTarget:self action:@selector(stepperValueChanged:) forControlEvents:UIControlEventValueChanged];
    
    
    UIButton *btn = (UIButton *)[cell viewWithTag:100];
    [btn addTarget:self action:@selector(upTapped:) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton *downBtn = (UIButton *)[cell viewWithTag:50];
    [downBtn addTarget:self action:@selector(downTapped:) forControlEvents:UIControlEventTouchUpInside];
    
    return cell;
}


- (void)upTapped:(id)paramSender
{
    UITableViewCell *cell = (UITableViewCell *)[paramSender superview];
    NSIndexPath *indexPath = [self.staticTable indexPathForCell:cell];
    NSMutableDictionary *tem = [self.mainArray objectAtIndex:indexPath.row];
    int val = [[tem objectForKey:@"value"] integerValue];
    val++;
    [tem setObject:[NSNumber numberWithInt:val] forKey:@"value"];
    //NSLog(@"%@",tem);
    [self.mainArray replaceObjectAtIndex:indexPath.row withObject:tem];
    
    /* replace text only */
    NSString *str = [[NSString alloc] initWithFormat:@"%@ (%@)",[tem objectForKey:@"name"],[tem objectForKey:@"value"] ];
    /* reload whole table */
    cell.textLabel.text = str;
    //[self.staticTable reloadData];
}


- (void)downTapped:(id)paramSender
{
    UITableViewCell *cell = (UITableViewCell *)[paramSender superview];
    NSIndexPath *indexPath = [self.staticTable indexPathForCell:cell];
    NSMutableDictionary *tem = [self.mainArray objectAtIndex:indexPath.row];
    int val = [[tem objectForKey:@"value"] integerValue];
    if (val>0) {
        val--;
    }
    [tem setObject:[NSNumber numberWithInt:val] forKey:@"value"];
    //NSLog(@"%@",tem);
    [self.mainArray replaceObjectAtIndex:indexPath.row withObject:tem];
    NSString *str = [[NSString alloc] initWithFormat:@"%@ (%@)",[tem objectForKey:@"name"],[tem objectForKey:@"value"] ];
    
    cell.textLabel.text = str;
    //[self.staticTable reloadData];
}

@end
