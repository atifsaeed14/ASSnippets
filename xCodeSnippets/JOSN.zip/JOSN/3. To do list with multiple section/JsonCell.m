//
//  JsonCell.m
//  3. To do list with multiple section
//
//  Created by Netsolace on 26/11/13.
//  Copyright (c) 2013 atif. All rights reserved.
//

#import "JsonCell.h"

@implementation JsonCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        
        /* price */
        self.price = [[UILabel alloc] initWithFrame:CGRectMake(260, 10, 40, 30)];
        self.price.textColor = [UIColor blackColor];
        self.price.textAlignment = UITextAlignmentCenter;
        self.price.font = [UIFont fontWithName:@"Arial" size:14.0f];
        [self addSubview:self.price];
        
        
        
        
        // Helpers
//        CGSize size = self.contentView.frame.size;
//        // Initialize Main Label
//        self.mainLabel = [[UILabel alloc] initWithFrame:CGRectMake(8.0, 8.0, size.width - 16.0, size.height - 16.0)];
//        // Configure Main Label
//        [self.mainLabel setFont:[UIFont boldSystemFontOfSize:24.0]];
//        [self.mainLabel setTextAlignment:NSTextAlignmentCenter];
//        [self.mainLabel setTextColor:[UIColor orangeColor]];
//        [self.mainLabel setAutoresizingMask:(UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight)];
//        // Add Main Label to Content View
//        [self.contentView addSubview:self.mainLabel];
        
        
        
//        self.title = [[UILabel alloc]init];
//        self.title.textAlignment = UITextAlignmentLeft;
//        self.title.font = [UIFont systemFontOfSize:14];
//        
//        self.subTitle = [[UILabel alloc]init];
//        self.subTitle.textAlignment = UITextAlignmentLeft;
//        self.subTitle.font = [UIFont systemFontOfSize:8];
//        
//        self.image = [[UIImageView alloc]init];
//        [self.contentView addSubview:self.title];
//        [self.contentView addSubview:self.subTitle];
//        [self.contentView addSubview:self.image];
        
        /* image */
        
        
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
