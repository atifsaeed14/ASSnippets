//
//  AddViewController.m
//  3. To do list with multiple section
//
//  Created by Netsolace on 21/11/13.
//  Copyright (c) 2013 atif. All rights reserved.
//

#import "AddViewController.h"

@interface AddViewController ()

@end

@implementation AddViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.addMessage.text = @"";
    
    /* keypad hidden */
    self.itemName.delegate = self;
    
    self.sectionHeader = @ [@"AAAs", @"BBBs", @"CCCs"];
    
    /* UI Picker View */
    //self.itemSection = [[UIPickerView alloc] init];
    //[self.view addSubview:self.itemSection];
    
    self.view.backgroundColor = [UIColor whiteColor];
	
    //self.alertView = [[UIAlertView alloc] initWithTitle:@"Error" message:@"Textfield cannot be null" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Ok", nil ];
    self.alertView = [[UIAlertView alloc] initWithTitle:@"Error" message:@"Textfield Null" delegate:self cancelButtonTitle:[self noButtonTitle] otherButtonTitles:[self yesButtonTitle], nil];
    
    /* UI picker while creating through code */
//    self.itemSection = [[UIPickerView alloc] init];
//    self.itemSection.showsSelectionIndicator = YES;
//    self.itemSection.dataSource = self;
//    self.itemSection.delegate = self;
//    self.itemSection.center = self.view.center;
//    [self.view addSubview:self.itemSection];

}

- (NSString *)yesButtonTitle
{
    return @"Yes";
}

- (NSString *)noButtonTitle
{
    return @"No";
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return NO;
}

- (void)viewDidUnload
{
    //[self setAdd:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(void)callBack:(UIButton *)sender{
    [self dismissModalViewControllerAnimated:YES];
}

-(void)callAdd:(UIButton *)sender {
    NSString *itemName = self.itemName.text;
    if ([itemName length] == 0) {
        [self.view endEditing:YES];
        self.addMessage.text = @"Can't add because Textfield is empty...?";
        [self.alertView show];
    }else {
        self.itemName.text = nil;
        [self.view endEditing:YES];
        NSLog(@"itemName: %@",itemName);
        self.addMessage.text = @"Item name add successfull...!";
        
        /* dictionary object */
        NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
        [dic setObject:itemName forKey:@"title"];
        [dic setObject:@"NO" forKey:@"state"];        
        
        NSInteger row;
        row = [self.itemSection selectedRowInComponent:0];
        //NSLog(@"%d",row);
        
        /* add dictionary object to array */
        NSMutableArray *secArray = [self.addItem objectAtIndex:row];
        [secArray addObject:dic];
        
        [self.addItem replaceObjectAtIndex:row withObject:secArray];
        
        /* write to plist */
        [self.addItem writeToFile:self.path atomically:YES];
    }
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    NSString *result = nil;
    if ([pickerView isEqual:self.itemSection]) {
        result = [self.sectionHeader objectAtIndex:row];
    }
    return result;    
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    NSInteger result = 0;
    if ([pickerView isEqual:self.itemSection]){
        result = 1;
    }   
    return result;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    NSInteger result = 0;
    if ([pickerView isEqual:self.itemSection]){
        result = [self.sectionHeader count];
    }
    return result;
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    NSString *buttonTitle = [alertView buttonTitleAtIndex:buttonIndex];
    NSLog(@"%@",buttonTitle);
    if ([buttonTitle isEqualToString: [self yesButtonTitle]]) {
        NSLog(@"yes");
    }
}
    
@end
