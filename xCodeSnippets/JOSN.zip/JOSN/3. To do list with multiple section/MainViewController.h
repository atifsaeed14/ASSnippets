//
//  MainViewController.h
//  3. To do list with multiple section
//
//  Created by Netsolace on 20/11/13.
//  Copyright (c) 2013 atif. All rights reserved.
//

#import <UIKit/UIKit.h>


@class AddViewController;

@interface MainViewController : UIViewController <UITableViewDataSource,UITableViewDelegate, UIActionSheetDelegate> {
    AddViewController *addVC;
}

//@property (strong, nonatomic) NSArray *items;
@property (strong, nonatomic) IBOutlet UITableView *itemListTV;
@property (strong, nonatomic) NSString *path;
@property (strong, nonatomic) NSMutableArray *itemList;

@property (strong, nonatomic) UIActionSheet * actionSheet;

- (void)callAdd;
- (void)callEdit;
- (void)callCancel;

@end
